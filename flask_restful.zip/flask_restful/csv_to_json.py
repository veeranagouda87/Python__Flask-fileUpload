import csv, json
from flask_cors import CORS
#read the csv and add the arr to a arrayn
def csv_to_json_conversion(csvFilePath, jsonFilePath = 'D:\\json_folder'):
    arr = []
    CORS(csvFilePath)
    with open (csvFilePath) as csvFile:
        csvReader = csv.DictReader(csvFile)
        print(csvReader)
        for csvRow in csvReader:
            arr.append(csvRow)

    print(arr)

    # write the data to a json file
    with open(jsonFilePath, "w") as jsonFile:
        jsonFile.write(json.dumps(arr, indent = 4))