from flask import Flask, request
from flask_restful import Resource, Api
import os
from flask_cors import CORS
import csv, json


app = Flask(__name__)
CORS(app)
api = Api(app)

def allowed_file(filename):
	return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

class HelloWorld(Resource):
    def post(self):
        file = request.files['file']
        file.save(os.path.join('D:\\upload_files', file.filename))
        print(type(file))
        file.close()
        convertFile('D:\\upload_Files\\'+file.filename)
        return 'success'

def convertFile(dataFile):
    arr = []
    with open (dataFile) as csvFile:
        csvReader = csv.DictReader(csvFile)
        print('csv reader : ',csvReader)
        for csvRow in csvReader:
            arr.append(csvRow)

    # write the data to a json file
    with open('D:\\json_folder\\demo.json', "w") as jsonFile:
        jsonFile.write(json.dumps(arr, indent = 4))


api.add_resource(HelloWorld, '/demo')

if __name__ == '__main__':
    app.run(debug=True)